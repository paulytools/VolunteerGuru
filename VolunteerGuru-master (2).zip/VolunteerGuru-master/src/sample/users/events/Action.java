package sample.users.events;

public enum Action {
	FOLLOW, EVENT, INVITE
}
